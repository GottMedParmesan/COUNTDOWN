# Progress Tracker App 🚀

Denna app låter dig spåra din framgång mellan två datum!

## 📌 Installation

1️⃣ **Ladda ner och installera Python** (om du inte redan har det) från https://www.python.org/downloads/  
2️⃣ **Öppna en terminal och installera Streamlit**  
   ```bash
   pip install -r requirements.txt
   ```
3️⃣ **Starta appen!**  
   ```bash
   streamlit run progress_tracker.py
   ```

✅ Nu kan du använda appen i din webbläsare! 🎉  
